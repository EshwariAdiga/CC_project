from flask import Flask, jsonify, render_template, request, redirect, url_for, flash, session
from flask_mysqldb import MySQL
import MySQLdb.cursors
from datetime import datetime
import os

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# These will now be injected via environment variables in Compose:
app.config['MYSQL_USER']     = os.environ['MYSQL_USER']
app.config['MYSQL_PASSWORD'] = os.environ['MYSQL_PASSWORD']
app.config['MYSQL_HOST']     = os.environ.get('MYSQL_HOST', 'db')
app.config['MYSQL_DB']       = os.environ['MYSQL_DB']

mysql = MySQL(app)

@app.route('/')
def index():
    if 'loggedin' in session:
        return redirect(url_for('home'))  # or your dashboard/home page after login
    else:
        return redirect(url_for('login'))


@app.route('/home')
def home():
    if 'loggedin' not in session:
        flash("Please log in first.")
        return redirect(url_for('login'))
    return render_template('index.html', name=session['name'])


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']  # get password from form

        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute("SELECT * FROM Faculty WHERE email = %s", (email,))
        user = cursor.fetchone()
        cursor.close()

        if user and user['password'] == password:  # check if password matches
            session['loggedin'] = True
            session['faculty_id'] = user['id']
            session['name'] = user['name']
            session['email'] = user['email']  # Store email
            session['gender'] = user['gender']
            flash('Logged in successfully!')
            return redirect(url_for('home'))
        else:
            flash('Invalid email or password. Please try again.')
            return redirect(url_for('login'))
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully.')
    return redirect(url_for('login'))

@app.route('/apply', methods=['GET', 'POST'])
def apply_leave():
    if 'loggedin' not in session:
        flash("Please log in first.")
        return redirect(url_for('login'))

    if request.method == 'POST':
        name = session['name']
        email = session['email']
        leave_type = request.form['leave_type']
        allow_unpaid = 'allow_unpaid' in request.form

        start = request.form['start_date']
        end = request.form['end_date']
        reason = request.form['reason']

        start_date = datetime.strptime(start, '%Y-%m-%d').date()
        end_date = datetime.strptime(end, '%Y-%m-%d').date()
        today = datetime.today().date()
        
        leave_days = (end_date - start_date).days + 1
        if leave_days <= 0:
            flash("End date must be after or equal to start date.")
            return redirect(url_for('apply_leave'))

        # ✅ Add this directly below
        if leave_days > 365:
            flash("Leave duration is too long. Please enter a valid range.")
            return redirect(url_for('apply_leave'))


        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)

        cursor.execute("SELECT * FROM Faculty WHERE email = %s", (email,))
        faculty = cursor.fetchone()

        if not faculty:
            # Faculty not found, so this is their first time applying
            gender = request.form.get('gender', 'Not Specified')
            cursor.execute("""
                INSERT INTO Faculty 
                (name, email, gender, casual_leaves, sick_leaves, earned_leaves, no_pay_leaves, 
                maternity_leaves, paternity_leaves, academic_leaves)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (name, email, gender, 8, 8, 10, 0, 180, 15, 20))
            mysql.connection.commit()

            cursor.execute("SELECT * FROM Faculty WHERE email = %s", (email,))
            faculty = cursor.fetchone()
        else:
            gender = faculty.get('gender', 'Not Specified')

        gender = gender.lower()
        faculty_id = faculty['id']
        # ✅ Overlapping leave check (add this block here)
        cursor.execute("""
            SELECT * FROM LeaveRequest
            WHERE faculty_id = %s AND status = 'Approved'
            AND (
                (start_date <= %s AND end_date >= %s) OR
                (start_date <= %s AND end_date >= %s) OR
                (%s <= start_date AND %s >= end_date)
            )
        """, (faculty_id, start_date, start_date, end_date, end_date, start_date, end_date))

        overlap = cursor.fetchone()
        if overlap:
            flash("You already have an approved leave during this period.")
            return redirect(url_for('apply_leave'))
        paid_days = 0
        no_pay_days = 0
        leave_status = "Approved"
        final_type = leave_type

        # === LEAVE TYPE LOGIC ===
        if leave_type.lower() == "casual":
            if leave_days > 3:
                flash("Casual leave cannot exceed 3 consecutive days.")
                return redirect(url_for('apply_leave'))
            if start_date <= today:
                flash("Casual leave must be applied in advance.")
                return redirect(url_for('apply_leave'))

            available = faculty.get('casual_leaves', 0)
            if leave_days <= available:
                paid_days = leave_days
                no_pay_days = 0
            else:
                if allow_unpaid:
                    paid_days = available
                    no_pay_days = leave_days - paid_days
                else:
                    flash(f"Only {available} {leave_type} days left. Either reduce the leave duration or allow unpaid conversion.")
                    return redirect(url_for('apply_leave'))


            cursor.execute("""
                UPDATE Faculty 
                SET casual_leaves = GREATEST(casual_leaves - %s, 0), 
                    no_pay_leaves = no_pay_leaves + %s 
                WHERE id = %s
            """, (paid_days, no_pay_days, faculty_id))

        elif leave_type.lower() == "sick":
            if start_date > today:
                flash("Sick leave must be retroactive or starting today.")
                return redirect(url_for('apply_leave'))
            if leave_days > 2:
                flash("Medical certificate required for sick leave over 2 days (not enforced in code).")
            available = faculty.get('sick_leaves', 0)
            if leave_days <= available:
                paid_days = leave_days
                no_pay_days = 0
            else:
                if allow_unpaid:
                    paid_days = available
                    no_pay_days = leave_days - paid_days
                else:
                    flash(f"Only {available} {leave_type} days left. Either reduce the leave duration or allow unpaid conversion.")
                    return redirect(url_for('apply_leave'))

            cursor.execute("""
                UPDATE Faculty 
                SET sick_leaves = GREATEST(sick_leaves - %s, 0), 
                    no_pay_leaves = no_pay_leaves + %s 
                WHERE id = %s
            """, (paid_days, no_pay_days, faculty_id))

        elif leave_type.lower() == "earned":
            if start_date <= today:
                flash("Earned leave must be applied in advance.")
                return redirect(url_for('apply_leave'))
            available = faculty.get('earned_leaves', 0)
            if leave_days <= available:
                paid_days = leave_days
                no_pay_days = 0
            else:
                if allow_unpaid:
                    paid_days = available
                    no_pay_days = leave_days - paid_days
                else:
                    flash(f"Only {available} {leave_type} days left. Either reduce the leave duration or allow unpaid conversion.")
                    return redirect(url_for('apply_leave'))

            cursor.execute("""
                UPDATE Faculty 
                SET earned_leaves = GREATEST(earned_leaves - %s, 0), 
                    no_pay_leaves = no_pay_leaves + %s 
                WHERE id = %s
            """, (paid_days, no_pay_days, faculty_id))

        elif leave_type.lower() == "maternity":
            if gender != "female":
                flash("Maternity leave is only applicable to female faculty.")
                return redirect(url_for('apply_leave'))
            if leave_days > 180:
                flash("Maternity leave cannot exceed 6 months (180 days).")
                return redirect(url_for('apply_leave'))

            available = faculty.get('maternity_leaves', 180)
            if leave_days <= available:
                paid_days = leave_days
                no_pay_days = 0
            else:
                if allow_unpaid:
                    paid_days = available
                    no_pay_days = leave_days - paid_days
                else:
                    flash(f"Only {available} {leave_type} days left. Either reduce the leave duration or allow unpaid conversion.")
                    return redirect(url_for('apply_leave'))


            cursor.execute("""
                UPDATE Faculty 
                SET maternity_leaves = GREATEST(maternity_leaves - %s, 0),
                    no_pay_leaves = no_pay_leaves + %s
                WHERE id = %s
            """, (paid_days, no_pay_days, faculty_id))

        elif leave_type.lower() == "paternity":
            if gender != "male":
                flash("Paternity leave is only applicable to male faculty.")
                return redirect(url_for('apply_leave'))
            if leave_days > 15:
                flash("Paternity leave cannot exceed 15 days.")
                return redirect(url_for('apply_leave'))

            available = faculty.get('paternity_leaves', 15)
            if leave_days <= available:
                paid_days = leave_days
                no_pay_days = 0
            else:
                if allow_unpaid:
                    paid_days = available
                    no_pay_days = leave_days - paid_days
                else:
                    flash(f"Only {available} {leave_type} days left. Either reduce the leave duration or allow unpaid conversion.")
                    return redirect(url_for('apply_leave'))

            cursor.execute("""
                UPDATE Faculty 
                SET paternity_leaves = GREATEST(paternity_leaves - %s, 0),
                    no_pay_leaves = no_pay_leaves + %s
                WHERE id = %s
            """, (paid_days, no_pay_days, faculty_id))


        elif leave_type.lower() in ["academic", "research"]:
            flash("Proof of academic/research purpose (invitation/registration) is required (not enforced in code).")
            final_type = "Academic/Research"

            available = faculty.get('academic_leaves', 0)
            if leave_days <= available:
                paid_days = leave_days
                no_pay_days = 0
            else:
                if allow_unpaid:
                    paid_days = available
                    no_pay_days = leave_days - paid_days
                else:
                    flash(f"Only {available} {leave_type} days left. Either reduce the leave duration or allow unpaid conversion.")
                    return redirect(url_for('apply_leave'))


            cursor.execute("""
                UPDATE Faculty 
                SET academic_leaves = GREATEST(academic_leaves - %s, 0),
                    no_pay_leaves = no_pay_leaves + %s
                WHERE id = %s
            """, (paid_days, no_pay_days, faculty_id))


        else:
            no_pay_days = leave_days
            final_type = "No Pay Leave"
            cursor.execute("UPDATE Faculty SET no_pay_leaves = no_pay_leaves + %s WHERE id = %s",
                           (no_pay_days, faculty_id))

        # === INSERT LEAVE REQUEST ===
        cursor.execute("""
            INSERT INTO LeaveRequest 
            (faculty_id, leave_type, start_date, end_date, reason, status, paid_days, unpaid_days)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """, (faculty_id, final_type, start_date, end_date, reason, leave_status, paid_days, no_pay_days))

        mysql.connection.commit()
        cursor.close()
        flash("Leave request submitted successfully.")
        return redirect(url_for('view_leaves'))

    else:
        name = session['name']
        email = session['email']

        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute("SELECT * FROM Faculty WHERE email = %s", (email,))
        faculty = cursor.fetchone()
        cursor.close()

        if faculty:
            gender = faculty.get('gender', 'Not Specified').lower()
        else:
            gender = 'not specified'

        return render_template('apply_leave.html', name=name, email=email, gender=gender)


@app.route('/view')
def view_leaves():
    if 'loggedin' not in session:
        flash("Please log in first.")
        return redirect(url_for('login'))

    faculty_id = session['faculty_id']
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    # After fetching faculty info
    gender = session['gender']  # assuming it's stored as 'Male' or 'Female'

    # ✅ Get leave requests for this faculty
    cursor.execute("""
        SELECT LeaveRequest.*, Faculty.name, Faculty.email 
        FROM LeaveRequest 
        JOIN Faculty ON LeaveRequest.faculty_id = Faculty.id 
        WHERE Faculty.id = %s
    """, (faculty_id,))
    leaves = cursor.fetchall()

    # ✅ Get leave balances for the faculty
    cursor.execute("SELECT * FROM Faculty WHERE id = %s", (faculty_id,))
    faculty = cursor.fetchone()

    balance = {
        'Casual Leaves': faculty['casual_leaves'],
        'Sick Leaves': faculty['sick_leaves'],
        'Earned Leaves': faculty['earned_leaves'],
        'Maternity Leaves': faculty['maternity_leaves'],
        'Paternity Leaves': faculty['paternity_leaves'],
        'Academic Leaves': faculty['academic_leaves'],
        'No Pay Leaves': faculty['no_pay_leaves']
    }

    # ✅ Calculate total leaves taken per type (approved only)
    cursor.execute("""
        SELECT leave_type, SUM(paid_days + unpaid_days) AS total 
        FROM LeaveRequest 
        WHERE faculty_id = %s AND status = 'Approved'
        GROUP BY leave_type
    """, (faculty_id,))
    summary = cursor.fetchall()
    cursor.close()

    # ✅ Map DB types to full label names
    type_map = {
        'Casual': 'Casual Leaves',
        'Sick': 'Sick Leaves',
        'Earned': 'Earned Leaves',
        'Maternity': 'Maternity Leaves',
        'Paternity': 'Paternity Leaves',
        'Academic/Research': 'Academic Leaves', 
        'No Pay': 'No Pay Leaves'
    }
    total_leaves = {
        'Casual Leaves': 8,
        'Sick Leaves': 8,
        'Earned Leaves': 10,
        'Maternity Leaves': 180,
        'Paternity Leaves': 15,
        'Academic Leaves': 20,
        'No Pay Leaves': 100  # optional, for completeness
    }

    

    # ✅ Build summary dict with full label names
    summary_dict = {}
    for row in summary:
        label = type_map.get(row['leave_type'], row['leave_type'] + ' Leaves')
        summary_dict[label] = row['total']
    # 🔧 Ensure all labels exist in summary_dict (even if zero)
    for label in type_map.values():
        summary_dict.setdefault(label, 0)


    # ✅ Generate leave counts in the correct label order
    leave_labels = list(type_map.values())
    leave_counts = [summary_dict.get(label, 0) for label in leave_labels]

    return render_template(
        'view_leaves.html',
        leaves=leaves,
        balance=balance,
        leave_labels=leave_labels,
        leave_counts=leave_counts,
        total_leaves=total_leaves,
        gender=gender

    )
@app.route('/leave/status')
def leave_status():
    if 'loggedin' not in session:
        flash("Please log in first.")
        return redirect(url_for('login'))
    
    faculty_id = session['faculty_id']
    
    # Query to fetch leave request status for the logged-in faculty
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute("""
        SELECT leave_type, start_date, end_date, reason, status
        FROM LeaveRequest
        WHERE faculty_id = %s
        ORDER BY start_date DESC
    """, (faculty_id,))
    leave_requests = cursor.fetchall()
    cursor.close()

    return render_template('leave_status.html', leave_requests=leave_requests)

@app.route('/api/leave/apply', methods=['POST'])
def api_apply_leave():
    data = request.get_json()
    faculty_id = data.get('faculty_id')  # Use faculty_id instead of name or email
    leave_type = data.get('leave_type')
    start_date = data.get('start_date')
    end_date = data.get('end_date')
    reason = data.get('reason')
    paid_days = data.get('paid_days', 0)
    unpaid_days = data.get('unpaid_days', 0)

    # Insert leave request into the database
    cur = mysql.connection.cursor()
    cur.execute("""
        INSERT INTO LeaveRequest (faculty_id, leave_type, start_date, end_date, reason, status, paid_days, unpaid_days)
        VALUES (%s, %s, %s, %s, %s, 'Pending', %s, %s)
    """, (faculty_id, leave_type, start_date, end_date, reason, paid_days, unpaid_days))
    mysql.connection.commit()
    cur.close()

    return jsonify({"message": "Leave request submitted successfully!"}), 201


@app.route('/api/leave/status', methods=['GET'])
def api_view_leave_status():
    # Get faculty_id from query parameters
    faculty_id = request.args.get('faculty_id')

    # Query the database for leave requests by faculty_id
    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT * FROM LeaveRequest WHERE faculty_id = %s ORDER BY start_date DESC", (faculty_id,))
    leave_status = cur.fetchall()
    cur.close()

    # If no leave requests found
    if not leave_status:
        return jsonify({"message": "No leave requests found for this faculty member."}), 404

    return jsonify(leave_status)

@app.route('/api/leaves/<faculty_id>')
def get_leave_data(faculty_id):
    # Return mock data for testing
    return jsonify({
        "faculty_id": faculty_id,
        "leave_balance": 5,
        "last_leave": "2025-04-01"
    })

import requests

# Function to get faculty exits data from faculty_exits service
def get_faculty_exits():
    response = requests.get('http://faculty_exits:5004/api/exits')  # Use the service name and port
    if response.status_code == 200:
        return response.json()  # Assuming response contains JSON data
    else:
        return {"error": "Failed to fetch faculty exits data"}

# Example of calling the function in your route
@app.route('/faculty-exits', methods=['GET'])
def faculty_exits():
    exits = get_faculty_exits()
    return jsonify(exits)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)