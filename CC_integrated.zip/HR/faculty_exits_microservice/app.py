from flask import Flask, render_template, request, redirect, url_for, flash, session
import MySQLdb
import MySQLdb.cursors
import os


import requests

ALLOWED_EXTENSIONS = {'pdf', 'doc', 'docx', 'txt'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


# Check if file extension is allowed
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

app = Flask(__name__)
app.secret_key = 'some_secret_key'  # Change this for production!

# MySQL config for faculty_db
#app.config['FACULTY_MYSQL_HOST'] = 'localhost'
app.config['FACULTY_MYSQL_HOST'] = 'db'
app.config['FACULTY_MYSQL_USER'] = 'root'
app.config['FACULTY_MYSQL_PASSWORD'] = 'Domaaru07' 
app.config['FACULTY_MYSQL_DB'] = 'faculty_exits'

# Helper for DB connection
def get_faculty_db():
    return MySQLdb.connect(
        host=app.config['FACULTY_MYSQL_HOST'],
        user=app.config['FACULTY_MYSQL_USER'],
        passwd=app.config['FACULTY_MYSQL_PASSWORD'],
        db=app.config['FACULTY_MYSQL_DB']
    )

@app.route('/')
def login_options():
    return render_template('login_options.html')

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        con = get_faculty_db()
        cur = con.cursor(MySQLdb.cursors.DictCursor)
        cur.execute("SELECT * FROM admin_details WHERE username=%s", (username,))
        user = cur.fetchone()
        cur.close()
        con.close()
        if user and user['password'] == password:
            session["admin_logged_in"] = True
            session["username"] = username
            flash("Logged in successfully as admin!")
            return redirect(url_for('admin_dashboard'))
        else:
            flash("Invalid admin credentials.")
    return render_template('admin_login.html')

@app.route('/admin/dashboard')
def admin_dashboard():
    if not session.get("admin_logged_in"):
        flash("Please log in as admin.")
        return redirect(url_for('admin_login'))
    con = get_faculty_db()
    cur = con.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT * FROM faculty_exits")
    faculty_exits = cur.fetchall()
    cur.close()
    con.close()
    return render_template('index.html', faculty_exits=faculty_exits)

@app.route('/add', methods=['GET', 'POST'])
def add_faculty_exit():
    if not session.get("admin_logged_in"):
        flash("Please log in as admin.")
        return redirect(url_for('admin_login'))

    error_message = None

    if request.method == 'POST':
        faculty_name = request.form['faculty_name']
        exit_date = request.form['exit_date']
        reason = request.form['reason']
        department = request.form['department']

        con = get_faculty_db()
        cur = con.cursor()

        # Check if the username exists
        cur.execute(
            "SELECT 1 FROM Faculty WHERE name = %s",
            (faculty_name,)
        )
        result = cur.fetchone()

        if result:
            cur.execute(
                """INSERT INTO faculty_exits (faculty_name, exit_date, reason, department)
                   VALUES (%s, %s, %s, %s)""",
                (faculty_name, exit_date, reason, department)
            )
            con.commit()
            cur.close()
            con.close()
            return redirect(url_for('admin_dashboard'))
        else:
            error_message = "Faculty username not found in records. Please check and try again."
            cur.close()
            con.close()

    return render_template('add_faculty_exit.html', error_message=error_message)



@app.route('/statistics')
def statistics():
    if not session.get("admin_logged_in"):
        flash("Please log in as admin.")
        return redirect(url_for('admin_login'))
    con = get_faculty_db()
    cur = con.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("""
        SELECT reason, COUNT(*) as count 
        FROM faculty_exits
        GROUP BY reason
        ORDER BY count DESC
    """)
    data = cur.fetchall()
    cur.close()
    con.close()
    reasons = [row['reason'] for row in data]
    counts = [row['count'] for row in data]
    return render_template('statistics.html', reasons=reasons, counts=counts)

@app.route('/admin/logout')
def admin_logout():
    session.pop("admin_logged_in", None)
    session.pop("username", None)
    flash("Admin logged out.")
    return redirect(url_for('admin_login'))

@app.route('/faculty/login', methods=['GET', 'POST'])
def faculty_login():
    if request.method == 'POST':
        print("Form keys received:", request.form.keys())  # Debug print
        username = request.form['username']
        password = request.form['password']
        con = get_faculty_db()
        cur = con.cursor(MySQLdb.cursors.DictCursor)
        cur.execute("SELECT * FROM Faculty WHERE username=%s", (username,))
        user = cur.fetchone()
        cur.close()
        con.close()
        if user and user['password'] == password:
            session["faculty_logged_in"] = True
            session["username"] = username
            flash("Faculty login successful!")
            return redirect(url_for('faculty_feedback'))
        else:
            flash("Invalid faculty credentials.")
    return render_template('faculty_login.html')

@app.route('/feedback', methods=['GET', 'POST'])
def faculty_feedback():
    if not session.get("faculty_logged_in"):
        flash("Please log in as faculty to submit your feedback.")
        return redirect(url_for('faculty_login'))

    if request.method == 'POST':
        name = request.form['name']
        department = request.form['department']
        reason = request.form['reason']

        # Handle file upload
        file = request.files['resignation_letter']  
        if file and allowed_file(file.filename):  
            # Read the file as bytes
            resignation_letter_data = file.read()
        else:
            flash("Invalid file type. Please upload a valid document (.pdf, .doc, .docx, .txt).")
            return redirect(url_for('faculty_feedback'))

        # Insert the form data and the file data (as BLOB) into the database
        con = get_faculty_db()
        cur = con.cursor()
        cur.execute(
            """INSERT INTO faculty_feedback (faculty_name, department, resignation_letter, reason)
               VALUES (%s, %s, %s, %s)""",
            (name, department, resignation_letter_data, reason)
        )
        con.commit()
        cur.close()
        con.close()
        flash("Resignation feedback submitted successfully!")
        return redirect(url_for('faculty_feedback'))

    return render_template('faculty_feedback.html')

# Utility function to allow specific file types
def allowed_file(filename):
    ALLOWED_EXTENSIONS = {'pdf', 'doc', 'docx', 'txt'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/faculty/logout')
def faculty_logout():
    session.pop("faculty_logged_in", None)
    session.pop("username", None)
    flash("Faculty logged out.")
    return redirect(url_for('faculty_login'))

from flask import jsonify

# ---------- API ROUTES ----------

@app.route('/api/faculty_exit/submit', methods=['POST'])
def api_submit_faculty_exit():
    data = request.get_json()
    faculty_name = data.get('faculty_name')
    exit_date = data.get('exit_date')
    reason = data.get('reason')
    department = data.get('department')

    if not all([faculty_name, exit_date, reason, department]):
        return jsonify({"error": "Missing fields"}), 400

    con = get_faculty_db()
    cur = con.cursor()

    cur.execute("SELECT 1 FROM Faculty WHERE name = %s", (faculty_name,))
    result = cur.fetchone()

    if not result:
        cur.close()
        con.close()
        return jsonify({"error": "Faculty name not found in records."}), 404

    cur.execute("""
        INSERT INTO faculty_exits (faculty_name, exit_date, reason, department)
        VALUES (%s, %s, %s, %s)
    """, (faculty_name, exit_date, reason, department))

    con.commit()
    cur.close()
    con.close()

    return jsonify({"message": "Faculty exit submitted successfully!"})


@app.route('/api/faculty_exit/status', methods=['GET'])
def api_faculty_exit_status():
    faculty_name = request.args.get('faculty_name')

    con = get_faculty_db()
    cur = con.cursor(MySQLdb.cursors.DictCursor)

    if faculty_name:
        cur.execute("SELECT * FROM faculty_exits WHERE faculty_name = %s", (faculty_name,))
    else:
        cur.execute("SELECT * FROM faculty_exits")

    exits = cur.fetchall()
    cur.close()
    con.close()

    return jsonify(exits)

@app.route('/exit/check_leaves/<faculty_id>', methods=['GET'])
def check_leave_status(faculty_id):
    try:
        leave_service_url = f'http://leave_mng_microservice:5000/api/leaves/{faculty_id}'
        response = requests.get(leave_service_url)

        if response.status_code == 200:
            return jsonify({
                "faculty_id": faculty_id,
                "leave_info": response.json()
            }), 200
        else:
            return jsonify({
                "error": f"Leave service returned status {response.status_code}",
                "details": response.text
            }), response.status_code

    except Exception as e:
        return jsonify({"error": str(e)}), 500

import requests

# Function to get student welfare data
def get_student_welfare_data():
    response = requests.get('http://student_welfare:5003/api/welfare')  # Use the service name and port
    if response.status_code == 200:
        return response.json()  # Assuming response contains JSON data
    else:
        return {"error": "Failed to fetch student welfare data"}

# Example of calling the function in your route
@app.route('/student-welfare', methods=['GET'])
def student_welfare():
    welfare = get_student_welfare_data()
    return jsonify(welfare)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
